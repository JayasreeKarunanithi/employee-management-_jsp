# Hotel Reservation System 酒店预约系统 in Java
  This is a command-line Hotel Reservation System which supports basic functions of managing hotel rooms and orders. This is a school project of Software Engineering.

Usage 使用方法
====

User UI
----
1. Reserve 预约
<br>2. Search 搜索

Admin UI
----
1. Room Add 增加房间
<br>2. Room Show 显示房间
<br>3. CheckIn/CheckOut 入住登记／结算
<br>4. Cancel Room 取消房间
