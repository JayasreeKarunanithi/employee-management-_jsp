public interface Showable {
	/**
	 * Prints information about implementing objects on STDOUT.
	 */
	public void show();
}